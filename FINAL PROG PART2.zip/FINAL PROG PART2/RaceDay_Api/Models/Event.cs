﻿
using System.ComponentModel.DataAnnotations;

namespace RaceDay.API.Models
{
    public class Event
    {
        [Key]
        public int EventID { get; set; }

        public int OrganiserID { get; set; }

        public string EventName { get; set; } = "";

        public string Description { get; set; } = "";

        public DateTime Date { get; set; }

        public string Location { get; set; } = "";

        public double Distance { get; set; }

        public string EventImage { get; set; } = "";
    }
}


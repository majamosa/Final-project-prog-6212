﻿
using System.ComponentModel.DataAnnotations;

namespace RaceDay.API.Models
{
    public class Result
    {
        [Key]
        public int ResultID { get; set; }

        public int EnrolmentID { get; set; }

        public string FinishingTime { get; set; } = "";

        public int Position { get; set; }
    }
}

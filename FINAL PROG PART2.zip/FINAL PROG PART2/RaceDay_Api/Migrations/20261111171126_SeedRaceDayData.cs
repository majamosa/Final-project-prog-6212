﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RaceDay_Api.Migrations
{
    public partial class SeedRaceDayData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}

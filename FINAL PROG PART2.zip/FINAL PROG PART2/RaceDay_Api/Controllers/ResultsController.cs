﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.Models;

namespace RaceDay.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ResultsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public ResultsController(RaceDayDbContext context)
        {
            _context = context;
        }

        // GET: api/results
        [HttpGet]
        public async Task<IActionResult> GetResults()
        {
            var results = await _context.Results.ToListAsync();
            return Ok(results);
        }

        // GET: api/results/1
        [HttpGet("{id}")]
        public async Task<IActionResult> GetResult(int id)
        {
            var result = await _context.Results.FindAsync(id);

            if (result == null)
                return NotFound("Result not found.");

            return Ok(result);
        }

        // POST: api/results
        [HttpPost]
        public async Task<IActionResult> CreateResult(Result result)
        {
            var enrolment = await _context.Enrolments.FindAsync(
                result.EnrolmentID);

            if (enrolment == null)
                return BadRequest("Enrolment not found.");

            bool resultExists = await _context.Results
                .AnyAsync(r => r.EnrolmentID == result.EnrolmentID);

            if (resultExists)
                return BadRequest("A result already exists for this enrolment.");

            result.ResultID = 0;

            _context.Results.Add(result);
            await _context.SaveChangesAsync();

            return StatusCode(201, result);
        }

        // PUT: api/results/1
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateResult(int id, Result update)
        {
            var result = await _context.Results.FindAsync(id);

            if (result == null)
                return NotFound("Result not found.");

            result.FinishingTime = update.FinishingTime;
            result.Position = update.Position;

            await _context.SaveChangesAsync();

            return Ok(result);
        }

        // DELETE: api/results/1
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteResult(int id)
        {
            var result = await _context.Results.FindAsync(id);

            if (result == null)
                return NotFound("Result not found.");

            _context.Results.Remove(result);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.Models;

namespace RaceDay.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public EventsController(RaceDayDbContext context)
        {
            _context = context;
        }

        // GET: api/events
        [HttpGet]
        public async Task<IActionResult> GetEvents()
        {
            var events = await _context.Events.ToListAsync();
            return Ok(events);
        }

        // GET: api/events/1
        [HttpGet("{id}")]
        public async Task<IActionResult> GetEvent(int id)
        {
            var eventItem = await _context.Events.FindAsync(id);

            if (eventItem == null)
                return NotFound("Event not found.");

            return Ok(eventItem);
        }

        // POST: api/events
        [HttpPost]
        public async Task<IActionResult> CreateEvent(Event eventItem)
        {
            var organiser = await _context.Users.FindAsync(
                eventItem.OrganiserID);

            if (organiser == null || organiser.Role != "Organiser")
                return BadRequest("Valid organiser not found.");

            eventItem.EventID = 0;

            _context.Events.Add(eventItem);
            await _context.SaveChangesAsync();

            return StatusCode(201, eventItem);
        }

        // PUT: api/events/1
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateEvent(int id, Event update)
        {
            var eventItem = await _context.Events.FindAsync(id);

            if (eventItem == null)
                return NotFound("Event not found.");

            eventItem.EventName = update.EventName;
            eventItem.Description = update.Description;
            eventItem.Date = update.Date;
            eventItem.Location = update.Location;
            eventItem.Distance = update.Distance;
            eventItem.EventImage = update.EventImage;

            await _context.SaveChangesAsync();

            return Ok(eventItem);
        }

        // DELETE: api/events/1
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            var eventItem = await _context.Events.FindAsync(id);

            if (eventItem == null)
                return NotFound("Event not found.");

            bool hasCategories = await _context.Categories
                .AnyAsync(c => c.EventID == id);

            bool hasEnrolments = await _context.Enrolments
                .AnyAsync(e => e.EventID == id);

            if (hasCategories || hasEnrolments)
                return Conflict("Event has categories or enrolments and cannot be deleted.");

            _context.Events.Remove(eventItem);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}

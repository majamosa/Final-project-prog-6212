﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.Models;

namespace RaceDay.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnrolmentsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public EnrolmentsController(RaceDayDbContext context)
        {
            _context = context;
        }

        // GET: api/enrolments
        [HttpGet]
        public async Task<IActionResult> GetEnrolments()
        {
            var enrolments = await _context.Enrolments.ToListAsync();
            return Ok(enrolments);
        }

        // GET: api/enrolments/1
        [HttpGet("{id}")]
        public async Task<IActionResult> GetEnrolment(int id)
        {
            var enrolment = await _context.Enrolments.FindAsync(id);

            if (enrolment == null)
                return NotFound("Enrolment not found.");

            return Ok(enrolment);
        }

        // POST: api/enrolments
        [HttpPost]
        public async Task<IActionResult> CreateEnrolment(Enrolment enrolment)
        {
            var user = await _context.Users.FindAsync(enrolment.UserID);
            var eventItem = await _context.Events.FindAsync(enrolment.EventID);
            var category = await _context.Categories.FindAsync(enrolment.CategoryID);

            if (user == null || user.Role != "Participant")
                return BadRequest("Valid participant not found.");

            if (eventItem == null)
                return BadRequest("Event not found.");

            if (category == null || category.EventID != enrolment.EventID)
                return BadRequest("Category does not belong to this event.");

            bool alreadyEnrolled = await _context.Enrolments
                .AnyAsync(e => e.UserID == enrolment.UserID
                            && e.EventID == enrolment.EventID);

            if (alreadyEnrolled)
                return BadRequest("Participant is already enrolled in this event.");

            enrolment.EnrolmentID = 0;
            enrolment.EnrolmentDate = DateTime.Now;
            enrolment.Status = "Pending";

            _context.Enrolments.Add(enrolment);
            await _context.SaveChangesAsync();

            return StatusCode(201, enrolment);
        }

        // PUT: api/enrolments/1
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateEnrolment(int id, Enrolment update)
        {
            var enrolment = await _context.Enrolments.FindAsync(id);

            if (enrolment == null)
                return NotFound("Enrolment not found.");

            enrolment.Status = update.Status;

            await _context.SaveChangesAsync();

            return Ok(enrolment);
        }

        // DELETE: api/enrolments/1
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEnrolment(int id)
        {
            var enrolment = await _context.Enrolments.FindAsync(id);

            if (enrolment == null)
                return NotFound("Enrolment not found.");

            bool hasResult = await _context.Results
                .AnyAsync(r => r.EnrolmentID == id);

            if (hasResult)
                return Conflict("Enrolment has a result and cannot be deleted.");

            _context.Enrolments.Remove(enrolment);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
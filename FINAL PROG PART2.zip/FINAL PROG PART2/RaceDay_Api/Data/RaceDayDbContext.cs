﻿
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Models;

namespace RaceDay.API.Data
{
    public class RaceDayDbContext : DbContext
    {
        public RaceDayDbContext(DbContextOptions<RaceDayDbContext> options)
            : base(options)
        {
        }

        // Database tables
        public DbSet<User> Users { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Enrolment> Enrolments { get; set; }
        public DbSet<Result> Results { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Relationships

            modelBuilder.Entity<Enrolment>()
                .HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserID);

            modelBuilder.Entity<Category>()
                .HasOne<Event>()
                .WithMany()
                .HasForeignKey(c => c.EventID);

            modelBuilder.Entity<Result>()
                .HasOne<Enrolment>()
                .WithOne()
                .HasForeignKey<Result>(r => r.EnrolmentID);

            modelBuilder.Entity<Event>()
                .HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.OrganiserID);


            // Seed sample users
            // Passwords are already hashed.

            modelBuilder.Entity<User>().HasData(
                new User
                {
                    UserID = 1,
                    FullName = "John Organiser",
                    Email = "organiser@raceday.com",
                    Password = "AQAAAAIAAYagAAAAEBC7IOc0QkgA1KAfLNecoFmEHYmFOB4PUvV6nUdbrZcbuONx/ojyu/FftREotSqPMQ==",
                    Role = "Organiser",
                    ProfileImage = ""
                },
                new User
                {
                    UserID = 2,
                    FullName = "Sarah Runner",
                    Email = "sarah@raceday.com",
                    Password = "AQAAAAIAAYagAAAAEDtLUq4QLLw1Wj+xhA7HhU4RWLBp8eritpRXCaj1XJensx6zRZIr96vT+1TXPzbTng==",
                    Role = "Participant",
                    ProfileImage = ""
                },
                new User
                {
                    UserID = 3,
                    FullName = "Peter Runner",
                    Email = "peter@raceday.com",
                    Password = "AQAAAAIAAYagAAAAEDtLUq4QLLw1Wj+xhA7HhU4RWLBp8eritpRXCaj1XJensx6zRZIr96vT+1TXPzbTng==",
                    Role = "Participant",
                    ProfileImage = ""
                }
            );


            // Seed sample events

            modelBuilder.Entity<Event>().HasData(
                new Event
                {
                    EventID = 1,
                    OrganiserID = 1,
                    EventName = "Pretoria City Marathon",
                    Description = "A running event through Pretoria.",
                    Date = new DateTime(2027, 3, 15),
                    Location = "Pretoria, South Africa",
                    Distance = 42.2,
                    EventImage = ""
                },
                new Event
                {
                    EventID = 2,
                    OrganiserID = 1,
                    EventName = "Johannesburg Fun Run",
                    Description = "A fun running event for everyone.",
                    Date = new DateTime(2027, 4, 10),
                    Location = "Johannesburg, South Africa",
                    Distance = 10,
                    EventImage = ""
                }
            );


            // Seed event categories

            modelBuilder.Entity<Category>().HasData(
                new Category
                {
                    CategoryID = 1,
                    EventID = 1,
                    CategoryName = "10 KM",
                    Distance = 10,
                    EntryFee = 150
                },
                new Category
                {
                    CategoryID = 2,
                    EventID = 1,
                    CategoryName = "Half Marathon",
                    Distance = 21.1,
                    EntryFee = 250
                },
                new Category
                {
                    CategoryID = 3,
                    EventID = 2,
                    CategoryName = "Fun Run",
                    Distance = 5,
                    EntryFee = 100
                }
            );


            // Seed enrolments

            modelBuilder.Entity<Enrolment>().HasData(
                new Enrolment
                {
                    EnrolmentID = 1,
                    UserID = 2,
                    EventID = 1,
                    CategoryID = 1,
                    EnrolmentDate = new DateTime(2026, 11, 11),
                    Status = "Approved"
                },
                new Enrolment
                {
                    EnrolmentID = 2,
                    UserID = 3,
                    EventID = 2,
                    CategoryID = 3,
                    EnrolmentDate = new DateTime(2026, 11, 11),
                    Status = "Pending"
                }
            );


            // Seed race results

            modelBuilder.Entity<Result>().HasData(
                new Result
                {
                    ResultID = 1,
                    EnrolmentID = 1,
                    FinishingTime = "01:25:30",
                    Position = 1
                }
            );
        }
    }
}

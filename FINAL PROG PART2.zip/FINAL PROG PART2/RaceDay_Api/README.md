:::writing{variant="document" id="63821"}
# RaceDay Application

## Requirements
- Docker Desktop
- .NET 10
- RaceDay API
- Azure Blob Storage configuration

## Running the Application with Docker

### 1. Start the API
Open the RaceDay solution in Visual Studio and start the `RaceDay_Api` project.

The API must be running before using the Docker website.

### 2. Build the Docker Image
Open PowerShell in the `RaceDay_Webs` project folder and run:

```powershell
docker build -t raceday-web .
```

### 3. Run the Docker Container

Run the following command:

```powershell
docker run -d --name raceday-web -p 8080:8080 --env-file .env raceday-web
```

### 4. Open the Website

Open your browser and visit:

http://localhost:8080

## Stopping the Container

```powershell
docker stop raceday-web
```

## Removing the Container

```powershell
docker rm raceday-web
```

## Security

Azure credentials are stored in a local `.env` file and are not included in the Docker image or source control.
:::
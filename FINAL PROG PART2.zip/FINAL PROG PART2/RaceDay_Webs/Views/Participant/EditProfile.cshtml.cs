using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RaceDay_Webs.Views.Participant
{
    public class EditProfileModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

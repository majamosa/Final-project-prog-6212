using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RaceDay_Webs.Views.Participant
{
    public class ProfileModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

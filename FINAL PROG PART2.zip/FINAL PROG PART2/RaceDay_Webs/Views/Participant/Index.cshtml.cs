using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RaceDay_Webs.Views.Participant
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RaceDay_Webs.Views.Account
{
    public class RegisterModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

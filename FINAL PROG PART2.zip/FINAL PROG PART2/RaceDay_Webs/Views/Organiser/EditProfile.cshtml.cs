using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RaceDay_Webs.Views.Organiser
{
    public class EditProfileModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

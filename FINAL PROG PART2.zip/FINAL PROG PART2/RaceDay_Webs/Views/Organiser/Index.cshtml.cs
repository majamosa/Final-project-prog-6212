using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RaceDay_Webs.Views.Organiser
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

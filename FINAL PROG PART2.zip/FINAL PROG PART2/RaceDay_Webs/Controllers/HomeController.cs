
using Microsoft.AspNetCore.Mvc;
using RaceDay_Web.Services;

namespace RaceDay_Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly RaceDayApiService _apiService;

        public HomeController(RaceDayApiService apiService)
        {
            _apiService = apiService;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
    }
}


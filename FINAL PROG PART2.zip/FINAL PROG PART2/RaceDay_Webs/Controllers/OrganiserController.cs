﻿
using Microsoft.AspNetCore.Mvc;
using RaceDay_Web.Services;
using RaceDay_Web.Models;

namespace RaceDay_Web.Controllers
{
    public class OrganiserController : Controller
    {
        private readonly RaceDayApiService _apiService;
        private readonly AzureBlobStorageService _blobService;
        public OrganiserController(
    RaceDayApiService apiService,
    AzureBlobStorageService blobService)
        {
            _apiService = apiService;
            _blobService = blobService;
        }
        // Organiser Dashboard
        public IActionResult Index()
        {
            int? userID = HttpContext.Session.GetInt32("UserID");

            if (userID == null)
                return RedirectToAction("Login", "Account");

            string? role = HttpContext.Session.GetString("Role");

            if (role != "Organiser")
                return RedirectToAction("Index", "Home");

            return View();
        }

        // View Organiser Profile
        public async Task<IActionResult> Profile()
        {
            int? userID = HttpContext.Session.GetInt32("UserID");

            if (userID == null)
                return RedirectToAction("Login", "Account");

            if (HttpContext.Session.GetString("Role") != "Organiser")
                return RedirectToAction("Index", "Home");

            try
            {
                var profile = await _apiService.GetAsync<UserProfileViewModel>(
                    $"api/users/{userID}");

                if (profile == null)
                    return NotFound("Organiser profile not found.");

                return View(profile);
            }
            catch (HttpRequestException)
            {
                return View("Error");
            }
        }

        // GET: Edit Organiser Profile
        [HttpGet]
        public async Task<IActionResult> EditProfile()
        {
            int? userID = HttpContext.Session.GetInt32("UserID");

            if (userID == null)
                return RedirectToAction("Login", "Account");

            if (HttpContext.Session.GetString("Role") != "Organiser")
                return RedirectToAction("Index", "Home");

            try
            {
                var profile = await _apiService.GetAsync<UserProfileViewModel>(
                    $"api/users/{userID}");

                if (profile == null)
                    return NotFound("Profile not found.");

                return View(profile);
            }
            catch (HttpRequestException)
            {
                return View("Error");
            }
        }

        // POST: Edit Organiser Profile
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditProfile(
            UserProfileViewModel model)
        {
            int? userID = HttpContext.Session.GetInt32("UserID");

            if (userID == null)
                return RedirectToAction("Login", "Account");

            if (HttpContext.Session.GetString("Role") != "Organiser")
                return RedirectToAction("Index", "Home");

            if (model.UserID != userID.Value)
                return Forbid();

            if (!ModelState.IsValid)
                return View(model);

            try
            {
                var updateData = new
                {
                    model.FullName,
                    model.Email,
                    model.ProfileImage
                };

                var response = await _apiService.PutAsync(
                    $"api/users/{userID}", updateData);

                if (response.IsSuccessStatusCode)
                {
                    TempData["Success"] = "Profile updated successfully!";

                    return RedirectToAction("Profile");
                }

                string error = await response.Content.ReadAsStringAsync();

                ModelState.AddModelError(
                    "",
                    string.IsNullOrWhiteSpace(error)
                        ? "Unable to update profile."
                        : error);

                return View(model);
            }
            catch (HttpRequestException)
            {
                ModelState.AddModelError(
                    "",
                    "Unable to connect to RaceDay API.");

                return View(model);
            }
        }
        // POST: Upload Organiser Profile Image
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UploadProfileImage(IFormFile profileImage)
        {
            int? userID = HttpContext.Session.GetInt32("UserID");

            if (userID == null)
                return RedirectToAction("Login", "Account");

            if (HttpContext.Session.GetString("Role") != "Organiser")
                return RedirectToAction("Index", "Home");

            if (profileImage == null || profileImage.Length == 0)
            {
                TempData["Error"] = "Please select an image.";
                return RedirectToAction("Profile");
            }

            string[] allowedTypes =
            {
        "image/jpeg",
        "image/png",
        "image/webp"
    };

            if (!allowedTypes.Contains(profileImage.ContentType))
            {
                TempData["Error"] = "Only JPG, PNG and WEBP images are allowed.";
                return RedirectToAction("Profile");
            }

            if (profileImage.Length > 5 * 1024 * 1024)
            {
                TempData["Error"] = "Image size cannot exceed 5 MB.";
                return RedirectToAction("Profile");
            }

            try
            {
                var profile = await _apiService.GetAsync<UserProfileViewModel>(
                    $"api/users/{userID}");

                if (profile == null)
                    return NotFound("Profile not found.");

                string fileName = await _blobService.UploadFileAsync(profileImage);

                var updateData = new
                {
                    profile.FullName,
                    profile.Email,
                    ProfileImage = fileName
                };

                var response = await _apiService.PutAsync(
                    $"api/users/{userID}", updateData);

                if (response.IsSuccessStatusCode)
                {
                    TempData["Success"] = "Profile image uploaded successfully!";
                }
                else
                {
                    TempData["Error"] = "Image uploaded, but the profile could not be updated.";
                }

                return RedirectToAction("Profile");
            }
            catch (HttpRequestException)
            {
                TempData["Error"] = "Unable to connect to the RaceDay API.";
                return RedirectToAction("Profile");
            }
            catch (Exception)
            {
                TempData["Error"] = "Unable to upload your profile image.";
                return RedirectToAction("Profile");
            }
        }
    }
}


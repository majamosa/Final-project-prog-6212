﻿using Microsoft.AspNetCore.Mvc;
using RaceDay_Web.Services;
using System.Net.Http.Json;
using RaceDay_Web.Models;

    
namespace RaceDay_Web.Controllers
{
    public class AccountController : Controller
    {
        private readonly RaceDayApiService _apiService;

        public AccountController(RaceDayApiService apiService)
        {
            _apiService = apiService;
        }

        // GET: Account/Register
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        // POST: Account/Register
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(
            RegistrationViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            if (model.Role != "Participant" &&
                model.Role != "Organiser")
            {
                ModelState.AddModelError(
                    "Role", "Please select a valid account type.");

                return View(model);
            }

            try
            {
                var userData = new
                {
                    model.FullName,
                    model.Email,
                    model.Password,
                    model.Role,
                    model.ProfileImage
                };

                var response = await _apiService.PostAsync(
                    "api/auth/register", userData);

                if (response.IsSuccessStatusCode)
                {
                    TempData["Success"] =
                        "Registration successful! You can now log in.";

                    return RedirectToAction("Login");
                }

                var error = await response.Content.ReadAsStringAsync();

                ModelState.AddModelError(
                    "", string.IsNullOrWhiteSpace(error)
                    ? "Registration failed."
                    : error);

                return View(model);
            }
            catch (HttpRequestException)
            {
                ModelState.AddModelError(
                    "", "Unable to connect to RaceDay API. Please try again.");

                return View(model);
            }
        }

        // GET: Account/Login
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        // POST: Account/Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            try
            {
                var loginData = new
                {
                    model.Email,
                    model.Password
                };

                var response = await _apiService.PostAsync(
                    "api/auth/login", loginData);

                if (response.IsSuccessStatusCode)
                {
                    var user = await response.Content.ReadFromJsonAsync<User>();

                    if (user == null)
                    {
                        ModelState.AddModelError(
                            "", "Unable to read user details.");

                        return View(model);
                    }

                    // Save user information in Session
                    HttpContext.Session.SetInt32("UserID", user.UserID);
                    HttpContext.Session.SetString("FullName", user.FullName);
                    HttpContext.Session.SetString("Role", user.Role);

                    // Redirect according to account role
                    if (user.Role == "Participant")
                    {
                        return RedirectToAction("Index", "Participant");
                    }
                    else if (user.Role == "Organiser")
                    {
                        return RedirectToAction("Index", "Organiser");
                    }

                    return RedirectToAction("Index", "Home");
                }

                ModelState.AddModelError(
                    "", "Invalid email or password.");

                return View(model);
            }
            catch (HttpRequestException)
            {
                ModelState.AddModelError(
                    "", "Unable to connect to RaceDay API.");

                return View(model);
            }
        }

        // POST: Account/Logout
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Logout()
        {
            // Clear the user's session
            HttpContext.Session.Clear();

            // Return to the homepage
            return RedirectToAction("Index", "Home");
        }

    }
}

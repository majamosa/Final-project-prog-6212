﻿
using Microsoft.AspNetCore.Mvc;
using RaceDay_Web.Services;
using RaceDay_Web.Models;

namespace RaceDay_Web.Controllers
{
    public class ParticipantController : Controller
    {
        private readonly RaceDayApiService _apiService;
        private readonly AzureBlobStorageService _blobService;
        public ParticipantController(
    RaceDayApiService apiService,
    AzureBlobStorageService blobService)
        {
            _apiService = apiService;
            _blobService = blobService;
        }

        // Participant Dashboard
        public IActionResult Index()
        {
            int? userID = HttpContext.Session.GetInt32("UserID");

            if (userID == null)
                return RedirectToAction("Login", "Account");

            string? role = HttpContext.Session.GetString("Role");

            if (role != "Participant")
                return RedirectToAction("Index", "Home");

            return View();
        }

        // View Participant Profile
        public async Task<IActionResult> Profile()
        {
            int? userID = HttpContext.Session.GetInt32("UserID");

            if (userID == null)
                return RedirectToAction("Login", "Account");

            string? role = HttpContext.Session.GetString("Role");

            if (role != "Participant")
                return RedirectToAction("Index", "Home");

            try
            {
                var profile = await _apiService.GetAsync<UserProfileViewModel>(
                    $"api/users/{userID}");

                if (profile == null)
                    return NotFound("Participant profile not found.");

                return View(profile);
            }
            catch (HttpRequestException)
            {
                return View("Error");
            }
        }

        // GET: Edit Profile
        [HttpGet]
        public async Task<IActionResult> EditProfile()
        {
            int? userID = HttpContext.Session.GetInt32("UserID");

            if (userID == null)
                return RedirectToAction("Login", "Account");

            if (HttpContext.Session.GetString("Role") != "Participant")
                return RedirectToAction("Index", "Home");

            try
            {
                var profile = await _apiService.GetAsync<UserProfileViewModel>(
                    $"api/users/{userID}");

                if (profile == null)
                    return NotFound("Profile not found.");

                return View(profile);
            }
            catch (HttpRequestException)
            {
                return View("Error");
            }
        }

        // POST: Edit Profile
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditProfile(
            UserProfileViewModel model)
        {
            int? userID = HttpContext.Session.GetInt32("UserID");

            if (userID == null)
                return RedirectToAction("Login", "Account");

            if (HttpContext.Session.GetString("Role") != "Participant")
                return RedirectToAction("Index", "Home");

            // Prevent changing another user's profile
            if (model.UserID != userID.Value)
                return Forbid();

            if (!ModelState.IsValid)
                return View(model);

            try
            {
                var updateData = new
                {
                    model.FullName,
                    model.Email,
                    model.ProfileImage
                };

                var response = await _apiService.PutAsync(
                 $"api/users/{userID}", updateData);
                // Use PUT instead of POST
                if (response.IsSuccessStatusCode)
                {
                    TempData["Success"] = "Profile updated successfully!";

                    return RedirectToAction("Profile");
                }

                string error = await response.Content.ReadAsStringAsync();

                ModelState.AddModelError(
                    "",
                    string.IsNullOrWhiteSpace(error)
                        ? "Unable to update profile."
                        : error);

                return View(model);
            }
            catch (HttpRequestException)
            {
                ModelState.AddModelError(
                    "",
                    "Unable to connect to RaceDay API.");

                return View(model);
            }
                    
            

        }
        // POST: Upload Profile Image
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UploadProfileImage(IFormFile profileImage)
        {
            int? userID = HttpContext.Session.GetInt32("UserID");

            if (userID == null)
                return RedirectToAction("Login", "Account");

            if (HttpContext.Session.GetString("Role") != "Participant")
                return RedirectToAction("Index", "Home");

            if (profileImage == null || profileImage.Length == 0)
            {
                TempData["Error"] = "Please select an image.";
                return RedirectToAction("Profile");
            }

            // Allow image files only
            string[] allowedTypes = { "image/jpeg", "image/png", "image/webp" };

            if (!allowedTypes.Contains(profileImage.ContentType))
            {
                TempData["Error"] = "Only JPG, PNG and WEBP images are allowed.";
                return RedirectToAction("Profile");
            }

            try
            {
                // Upload image to Azure
                string fileName = await _blobService.UploadFileAsync(profileImage);

                // Save the Azure blob name in the database
                var updateData = new
                {
                    FullName = HttpContext.Session.GetString("FullName"),
                    Email = "", // We will correct this using the existing profile data
                    ProfileImage = fileName
                };

                TempData["Error"] = "Image uploaded to Azure. We still need to save its name to your profile.";

                return RedirectToAction("Profile");
            }
            catch (Exception)
            {
                TempData["Error"] = "Unable to upload your image.";
                return RedirectToAction("Profile");
            }
        }
    }
}


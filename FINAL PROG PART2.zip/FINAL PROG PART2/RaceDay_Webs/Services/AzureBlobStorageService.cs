﻿
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace RaceDay_Web.Services
{
    public class AzureBlobStorageService
    {
        private readonly BlobContainerClient _containerClient;

        public AzureBlobStorageService(IConfiguration configuration)
        {
            string connectionString =
                configuration["AzureStorage:ConnectionString"]!;

            string containerName =
                configuration["AzureStorage:ContainerName"]!;

            var blobServiceClient =
                new BlobServiceClient(connectionString);

            _containerClient =
                blobServiceClient.GetBlobContainerClient(containerName);
        }

        public async Task<string> UploadFileAsync(IFormFile file)
        {
            await _containerClient.CreateIfNotExistsAsync(
                PublicAccessType.None);

            string fileName =
                Guid.NewGuid().ToString() +
                Path.GetExtension(file.FileName);

            var blobClient =
                _containerClient.GetBlobClient(fileName);

            using (var stream = file.OpenReadStream())
            {
                await blobClient.UploadAsync(
                    stream,
                    new BlobHttpHeaders
                    {
                        ContentType = file.ContentType
                    });
            }

            return fileName;
        }
        // Download a profile image from Azure
        public async Task<BlobDownloadResult> DownloadFileAsync(string fileName)
        {
            var blobClient = _containerClient.GetBlobClient(fileName);

            var response = await blobClient.DownloadContentAsync();

            return response.Value;
        }
    }
}

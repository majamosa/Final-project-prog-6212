﻿
using System.ComponentModel.DataAnnotations;

namespace RaceDay_Web.Models
{
    public class CreateEventViewModel
    {
        [Required(ErrorMessage = "Please enter the race name.")]
        public string EventName { get; set; } = "";

        [Required(ErrorMessage = "Please enter a description.")]
        public string Description { get; set; } = "";

        [Required(ErrorMessage = "Please select a race date.")]
        public DateTime Date { get; set; }

        [Required(ErrorMessage = "Please enter the race location.")]
        public string Location { get; set; } = "";

        [Required(ErrorMessage = "Please enter the race distance.")]
        public string Distance { get; set; } = "";

        public string EventImage { get; set; } = "";
    }
}
